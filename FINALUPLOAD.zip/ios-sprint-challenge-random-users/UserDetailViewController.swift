//
//  UserDetailViewController.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import UIKit
import Foundation

class UserDetailViewController: UIViewController {
    
    // MARK: - OUTLETS
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var nameLabel2: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var phoneLabel2: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailLabel2: UILabel!
    // MARK: - PROPERTIES
    var user: User! {
        didSet {
            updateViews()
        }
    }
    
    // MARK: - METHODS
    
    private func updateViews() {
        guard let user = user else {
            print("user not getting ported")
            return
        }
        print(user.name.fullName)
        
        guard self.nameLabel2 != nil else {
           print("I'm an empty Label")
            return
        }

        self.nameLabel2.text = user.name.fullName
        
        self.phoneLabel2.text = user.phone
        self.emailLabel2.text = user.email
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()

        // Do any additional setup after loading the view.
    }

}
