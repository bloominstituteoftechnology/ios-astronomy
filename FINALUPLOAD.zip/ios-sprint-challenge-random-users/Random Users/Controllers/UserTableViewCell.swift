//
//  UserTableViewCell.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import UIKit

class UserTableViewCell: UITableViewCell {
    
    // MARK: - OUTLETS
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var thumbnailIV: UIImageView!
    
    // MARK: - PROPERTIES
    var user: User! {
        didSet {
            updateViews()
        }
    }
    
    // MARK: - METHODS
    
    private func updateViews() {
        nameLabel.text = user.name.fullName
    }
    
    // MARK: - OVERRIDES
    
    override func prepareForReuse() {
        super.prepareForReuse()
        thumbnailIV.image = #imageLiteral(resourceName: "Lambda_Logo_Full")
        nameLabel.text = nil
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
