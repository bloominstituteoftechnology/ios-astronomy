//
//  User.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import Foundation

struct Picture: Codable {
    var large: URL
    var medium: URL
    var thumbnail: URL
}

struct User: Codable {
    var name: Name
    var email: String
    var phone: String
    var picture: Picture
}

// Expanded Data
struct Name: Codable {
    var title: String
    var first: String
    var last: String
    var fullName: String {
        "\(title) \(first) \(last)"
    }


}

