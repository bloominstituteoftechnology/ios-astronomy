//
//  FetchPhotoOperation.swift
//  Astronomy
//
//  Created by Lambda_School_Loaner_268 on 4/9/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation

class FetchPhotoOperation: ConcurrentOperation {
    var reference: MarsPhotoReference
    var data: Data?
    private var task: URLSessionDataTask?
    
    init(reference: MarsPhotoReference) {
        self.reference = reference
        super.init()
    }
    
    override func start() {
        state = .isExecuting
        fetchPhoto()
        task?.resume()
    }
    
    override func cancel() {
        state = .isFinished
        fetchPhoto()
        task?.cancel()
    }
    
    func fetchPhoto() {
        guard let url = reference.imageURL.usingHTTPS else { return }
        task = URLSession.shared.dataTask(with: url) { (data, _, error) in
            defer {
                self.state = .isFinished
            }
            if let error = error {
                print(error)
                return
            }
            guard let data = data else {
                print("No data")
                return
            }
            self.data = data
        }
    }
}
